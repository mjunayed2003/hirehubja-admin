import React, { useState } from "react";
import { useGetUserByIdQuery, useApproveUserMutation, useRejectUserMutation } from "../../redux/features/users/usersApi";
import defaultPic from "../../assets/images/profile.png";
import toast from "react-hot-toast";

// ─── Image/File Modal (Fixed Height Issue) ────────────────────────────
const FileModal = ({ url, title, onClose }) => (
  <div className="fixed inset-0 z-[999] flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
    <div className="bg-white w-full max-w-4xl rounded-xl flex flex-col shadow-2xl overflow-hidden max-h-[90vh]">
      {/* Modal Header */}
      <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center shrink-0">
        <h3 className="text-lg font-bold text-gray-800">{title}</h3>
        <button onClick={onClose} className="text-gray-400 hover:text-red-500 text-3xl leading-none">&times;</button>
      </div>

      {/* Modal Body (Scrollable with max height) */}
      <div className="flex-1 overflow-auto bg-gray-50 flex justify-center items-center p-6">
        {url?.toLowerCase().endsWith(".pdf") ? (
          <iframe src={url} className="w-full h-[70vh] rounded shadow-sm" title={title} />
        ) : (
          <img 
            src={url} 
            alt={title} 
            className="max-w-full max-h-[70vh] object-contain shadow-sm rounded-lg" 
          />
        )}
      </div>

      {/* Modal Footer */}
      <div className="px-6 py-4 border-t border-gray-200 flex justify-end shrink-0">
        <button onClick={onClose} className="px-6 py-2 bg-gray-200 text-gray-600 rounded-full font-semibold hover:bg-gray-300 transition">
          Close
        </button>
      </div>
    </div>
  </div>
);

// ─── Main Component ───────────────────────────────────────────────
const RegistrationDetails = ({ user: rowData, onBack, onActionDone }) => {
  const[modalData, setModalData] = useState(null);
  const baseUrl = import.meta.env.VITE_SERVER_URL?.replace(/\/$/, "");

  const userId = rowData?.userId || rowData?.id;
  const { data, isLoading } = useGetUserByIdQuery(userId, { skip: !userId });
  const[approveUser, { isLoading: isApproving }] = useApproveUserMutation();
  const[rejectUser,  { isLoading: isRejecting  }] = useRejectUserMutation();

  const user    = data?.data || {};
  const profile = user?.jobSeekerProfile || user?.employerProfile || {};

  const isJobSeeker = user?.role === "JOB_SEEKER";
  const isEmployer  = user?.role === "EMPLOYER";
  const isCompany   = user?.role === "COMPANY";

  const imgUrl = (path) =>
    path && !path.includes("undefined") ? `${baseUrl}${path}` : null;

  const profilePic = imgUrl(profile?.profilePic) || defaultPic;

  const handleApprove = async () => {
    try {
      await approveUser(userId).unwrap();
      toast.success("User approved!");
      onBack();
      onActionDone?.();
    } catch (error) {
      toast.error(error?.data?.message || "Failed to approve");
    }
  };

  const handleDecline = async () => {
    try {
      await rejectUser(userId).unwrap();
      toast.success("User rejected!");
      onBack();
      onActionDone?.();
    } catch (error) {
      toast.error(error?.data?.message || "Failed to reject");
    }
  };

  if (isLoading) {
    return (
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 min-h-[400px] flex items-center justify-center">
        <div className="w-10 h-10 border-4 border-green-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 font-sans w-full max-w-[1400px] mx-auto my-8">

      {/* Header */}
      <div className="flex justify-between items-center mb-8 pb-4 border-b border-dashed border-gray-200">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="w-9 h-9 rounded-full border border-gray-300 flex items-center justify-center hover:bg-gray-100 transition text-gray-600">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M19 12H5"/><path d="M12 19l-7-7 7-7"/></svg>
          </button>
          <h3 className="text-xl font-bold text-gray-800">Registration Details</h3>
        </div>
        <span className="px-4 py-1.5 border border-gray-200 rounded text-sm font-semibold text-gray-600 bg-gray-50 shadow-sm uppercase tracking-wide">
          {user?.role?.replace("_", " ") || "User"}
        </span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">

        {/* ── Column 1: Basic Profile Info ── */}
        <div className="lg:col-span-4 space-y-5 lg:border-r border-dashed border-gray-200 lg:pr-8">
          <h4 className="font-bold text-gray-800 text-sm uppercase tracking-wide text-gray-400 mb-4 border-b pb-2">Basic Information</h4>

          <div className="mb-6 flex flex-col items-center lg:items-start">
            <div className="w-32 h-32 rounded-xl overflow-hidden border border-gray-200 shadow-sm mb-2">
              <img src={profilePic} alt="Profile" className="w-full h-full object-cover" />
            </div>
          </div>

          <div className="space-y-4 text-sm">
            <InfoRow label="Full Name" value={profile?.fullName} />
            <InfoRow label="Email"     value={user?.email} />
            <InfoRow label="Phone"     value={profile?.phone} />
            <InfoRow label="Location"  value={profile?.location} />

            {/* Job Seeker specific Basic Info */}
            {isJobSeeker && (
              <>
                <InfoRow label="Gender" value={profile?.gender} />
                <InfoRow label="Date of Birth" value={profile?.dob ? new Date(profile.dob).toLocaleDateString() : null} />
                <InfoRow label="Experience Level" value={profile?.experienceLevel?.replace("_", " ")} />
                <InfoRow label="Preferred Categories" value={profile?.preferredJobCategories?.map(c => c.name).join(", ")} />
              </>
            )}

            {/* Company specific Basic Info */}
            {isCompany && (
              <>
                <InfoRow label="Company Name" value={profile?.companyName} />
                <InfoRow label="Website"      value={profile?.website} />
              </>
            )}
          </div>
        </div>

        {/* ── Column 2: Additional Details / Professional ── */}
        <div className="lg:col-span-4 space-y-6 lg:border-r border-dashed border-gray-200 lg:pr-8">

          {/* Job Seeker - Education & Experience */}
          {isJobSeeker && (
            <>
              {profile?.education?.length > 0 && (
                <div>
                  <h4 className="font-bold text-gray-800 text-sm uppercase tracking-wide text-gray-400 mb-4 border-b pb-2">Educational Details</h4>
                  {profile.education.map((edu, i) => (
                    <div key={i} className="space-y-2 text-sm mb-4 pb-4 border-b border-gray-100 last:border-0">
                      <InfoRow label="Qualification"   value={edu.degreeName} />
                      <InfoRow label="Institution"     value={edu.institution} />
                      <InfoRow label="Started Year"    value={edu.startDate    ? new Date(edu.startDate).getFullYear()    : null} />
                      <InfoRow label="Completion Year" value={edu.completionYear ? new Date(edu.completionYear).getFullYear() : null} />
                    </div>
                  ))}
                </div>
              )}

              <div>
                <h4 className="font-bold text-gray-800 text-sm uppercase tracking-wide text-gray-400 mb-4 border-b pb-2">Professional Details</h4>

                {profile?.resumeUrl && (
                  <div className="flex items-center justify-between p-3 rounded-lg border border-gray-200 mb-4 shadow-sm bg-gray-50">
                    <span className="text-xs text-gray-600 font-semibold">CV / Resume:</span>
                    <button
                      onClick={() => setModalData({ url: imgUrl(profile.resumeUrl), title: "Resume" })}
                      className="px-4 py-1.5 bg-white border border-gray-300 rounded text-xs font-semibold text-gray-700 hover:bg-gray-100 transition shadow-sm"
                    >
                      View Resume
                    </button>
                  </div>
                )}

                {profile?.experience?.length > 0 && (
                  <>
                    <p className="text-xs text-gray-500 font-semibold mb-2 uppercase">Experience</p>
                    {profile.experience.map((exp, i) => (
                      <div key={i} className="space-y-2 text-sm mb-4 pb-4 border-b border-gray-100 last:border-0">
                        <InfoRow label="Designation"    value={exp.designation} />
                        <InfoRow label="Company"        value={exp.companyName} />
                        <InfoRow label="Started"        value={exp.startDate ? new Date(exp.startDate).getFullYear() : null} />
                        <InfoRow label="Ended"          value={exp.isCurrent ? "Present" : exp.endDate ? new Date(exp.endDate).getFullYear() : null} />
                      </div>
                    ))}
                  </>
                )}

                {profile?.skills?.length > 0 && (
                  <div className="mt-4">
                    <p className="text-xs text-gray-500 font-semibold mb-2 uppercase">Skills</p>
                    <div className="flex flex-wrap gap-2">
                      {profile.skills.map((skill, i) => (
                        <span key={i} className="bg-green-50 text-green-700 border border-green-100 px-3 py-1 rounded-md text-xs font-semibold">{skill}</span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </>
          )}

          {/* Employer / Company - Details & About */}
          {(isEmployer || isCompany) && (
            <div>
              <h4 className="font-bold text-gray-800 text-sm uppercase tracking-wide text-gray-400 mb-4 border-b pb-2">Company Information</h4>
              
              {isCompany && (
                <div className="space-y-4 text-sm mb-6">
                  <InfoRow label="Business Reg Cert ID" value={profile?.businessRegCertId} />
                  <InfoRow label="Tax ID"               value={profile?.taxId} />
                  <InfoRow label="Authorized Rep ID"    value={profile?.authorizedRepId} />
                </div>
              )}

              {profile?.about && (
                <div className="space-y-1">
                  <span className="text-gray-400 block text-xs font-semibold uppercase">About</span>
                  <p className="text-sm text-gray-700 leading-relaxed bg-gray-50 p-4 rounded-xl border border-gray-100 shadow-inner">
                    {profile.about}
                  </p>
                </div>
              )}
            </div>
          )}
        </div>

        {/* ── Column 3: Verification Documents & Action ── */}
        <div className="lg:col-span-4 flex flex-col">
          <h4 className="font-bold text-gray-800 text-sm uppercase tracking-wide text-gray-400 mb-4 border-b pb-2">Verification Documents</h4>

          <div className="space-y-4 flex-1">

            {/* Job Seeker / Employer verification docs */}
            {(isJobSeeker || isEmployer) && (
              <>
                <VerificationItem label="Govt. ID (Front)" btnText="View Front" url={imgUrl(profile?.idCardFront)} onView={(url) => setModalData({ url, title: "ID Card Front" })} />
                <VerificationItem label="Govt. ID (Back)"  btnText="View Back"  url={imgUrl(profile?.idCardBack)}  onView={(url) => setModalData({ url, title: "ID Card Back" })} />
                <VerificationItem label="Selfie Image"     btnText="View Selfie" url={imgUrl(profile?.selfieImage)} onView={(url) => setModalData({ url, title: "Selfie Image" })} />
              </>
            )}

            {/* Company verification docs */}
            {isCompany && (
              <>
                <VerificationItem label="Business License File" btnText="View License" url={imgUrl(profile?.licenseFile)} onView={(url) => setModalData({ url, title: "License File" })} />
              </>
            )}
          </div>

          {/* Approve / Decline buttons */}
          {user?.status === "PENDING" && (
            <div className="flex justify-end gap-3 mt-10 pt-6 border-t border-gray-200">
              <button onClick={handleDecline} disabled={isRejecting}
                className="bg-red-50 text-red-600 border border-red-200 px-6 py-2.5 rounded-lg text-sm font-bold hover:bg-red-100 transition disabled:opacity-60 w-full sm:w-auto">
                {isRejecting ? "Declining..." : "Decline"}
              </button>
              <button onClick={handleApprove} disabled={isApproving}
                className="bg-green-600 text-white px-6 py-2.5 rounded-lg text-sm font-bold hover:bg-green-700 shadow-md transition disabled:opacity-60 w-full sm:w-auto">
                {isApproving ? "Approving..." : "Approve Now"}
              </button>
            </div>
          )}

          {user?.status && user.status !== "PENDING" && (
            <div className="flex justify-end mt-10 pt-6 border-t border-gray-200">
              <span className={`px-6 py-2 rounded-lg text-sm font-bold ${
                user.status === "ACTIVE" ? "bg-green-100 text-green-700 border border-green-200" : "bg-red-100 text-red-600 border border-red-200"
              }`}>
                Status: {user.status}
              </span>
            </div>
          )}
        </div>
      </div>

      {/* File/Image Modal Component */}
      {modalData && (
        <FileModal url={modalData.url} title={modalData.title} onClose={() => setModalData(null)} />
      )}
    </div>
  );
};

// ─── Helper Components ────────────────────────────────────────────
const InfoRow = ({ label, value }) => (
  <p className="text-gray-800 flex flex-col">
    <span className="text-gray-400 text-xs font-semibold uppercase tracking-wider mb-0.5">{label}</span>
    {value ? <span className="font-medium text-[15px]">{value}</span> : <span className="text-gray-300 italic text-[14px]">Not provided</span>}
  </p>
);

const VerificationItem = ({ label, btnText, url, onView }) => (
  <div className="flex items-center justify-between p-4 border border-gray-200 rounded-xl bg-gray-50/50 hover:bg-white hover:shadow-md transition duration-200">
    <span className="text-sm text-gray-600 font-semibold">{label}</span>
    {url ? (
      <button onClick={() => onView(url)}
        className="px-4 py-1.5 bg-white border border-gray-300 shadow-sm rounded text-xs font-bold text-gray-700 hover:text-green-600 hover:border-green-400 transition">
        {btnText}
      </button>
    ) : (
      <span className="text-xs text-red-400 bg-red-50 px-2 py-1 rounded border border-red-100 font-medium italic">Missing File</span>
    )}
  </div>
);

export default RegistrationDetails;